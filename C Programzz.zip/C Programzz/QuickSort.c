#include<stdio.h>
void quick_sort(int arr[] , int first , int last);
int partition(int arr[] , int first , int last);
void display_arr(int arr[] , int n);
void main(){
int i,n;
int arr[50];
printf("Enter the number of elements ");
scanf("%d",&n);
printf("Enter the elements of the array \n");
for(i =0; i<n; i++){
scanf("%d",&arr[i]);}
quick_sort(arr,0,n-1);
printf("Elements after sorting ");
display_arr(arr,n);
}
void display_arr(int arr[] , int n){
int i;
for(i =0; i<n; i++){
printf("%d ",arr[i]);}
}
void quick_sort(int arr[] , int first , int last){
int pindex;
if(first<last){
pindex = partition(arr,first,last);
quick_sort(arr,first, pindex - 1);
quick_sort(arr,pindex + 1 , last);
}}
int partition(int arr[] , int first , int last){
int pivot,i,j,temp;
pivot = arr[first];
i = first;
j =last;
while(i<j){
while(arr[i]<=pivot && i<last){
i++;}
while(arr[j]>pivot && j>first){
j--;}
if(i<j){
temp = arr[i];
arr[i] = arr[j];
arr[j] = temp;
} }
temp = arr[first];
arr[first] = arr[j];
arr[j] = temp;
return j;
}