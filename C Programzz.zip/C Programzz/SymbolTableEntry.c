#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 50 


struct SymbolTableEntry {
    char symbol[20];
    char type[10];
    void *address;
};
struct SymbolTableEntry table[SIZE];
int count = 0;

void insert(char *symbol, char *type, void *address) {
    if (count >= SIZE) {
        printf("Symbol Table is Full!\n");
        return;
    }

    for (int i = 0; i < count; i++) {
        if (strcmp(table[i].symbol, symbol) == 0) {
            printf("Error: Duplicate Symbol '%s'!\n", symbol);
            return;
        }
    }
    
    strcpy(table[count].symbol, symbol);
    strcpy(table[count].type, type);
    table[count].address = address;
    count++;
    printf("Inserted: %s | %s | %p\n", symbol, type, address);
}

void display() {
    printf("\nSymbol Table:\n");
    printf("%-15s %-10s %-15s\n", "Symbol", "Type", "Address");
    printf("---------------------------------------------\n");
    for (int i = 0; i < count; i++) {
        printf("%-15s %-10s %p\n", table[i].symbol, table[i].type, table[i].address);
    }
}

int main() {
    int choice;
    char symbol[20], type[10];
    int dummy; // Just to get an address

    while (1) {
        printf("\n1. Insert\n2. Display\n3. Exit\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter Symbol: ");
                scanf("%s", symbol);
                printf("Enter Type: ");
                scanf("%s", type);
                insert(symbol, type, &dummy);
                break;
            
            case 2:
                display();
                break;
            
            case 3:
                exit(0);
            
            default:
                printf("Invalid choice!\n");
        }
    }
    return 0;
}