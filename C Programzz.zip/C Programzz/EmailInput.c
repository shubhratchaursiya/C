#include <stdio.h>
#include <string.h>
#include <ctype.h>


int isValidEmail(const char *email) {
    int atCount = 0, dotCount = 0;
    int atIndex = -1, dotIndex = -1;
    int len = strlen(email);

   
    if (len < 8) return 0;

    for (int i = 0; i < len; i++) {
        char ch = email[i];

        if (!(isalnum(ch) || ch == '@' || ch == '.' || ch == '_' || ch == '-'))
            return 0;

        if (ch == '@') {
            atCount++;
            atIndex = i;
        }
        if (ch == '.') {
            dotCount++;
            dotIndex = i;
        }
    }

    if (atCount != 1) return 0;
    if (dotIndex < atIndex) return 0;
    if (atIndex == 0 || atIndex == len - 1) return 0;
    if (dotIndex == len - 1) return 0;
    if (dotIndex - atIndex < 2) return 0;

    return 1; 
}

int main() {
    char email[100];

    printf("Enter an email address: ");
    if (fgets(email, sizeof(email), stdin) != NULL) {
        email[strcspn(email, "\n")] = '\0'; 
        if (isValidEmail(email))
            printf("Valid email address.\n");
        else
            printf("Invalid email address.\n");
    } else {
        printf("Input error!\n");
    }

    return 0;
}