#include <stdio.h>
int main() {
    int a[100], n, i, pos, val;
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter elements:\n");
    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter position to insert (0-based index): ");
    scanf("%d", &pos);
    printf("Enter value to insert: ");
    scanf("%d", &val);
    for(i = n; i > pos; i--)
        a[i] = a[i - 1];
    a[pos] = val;
    n++;
    printf("Array after insertion:\n");
    for(i = 0; i < n; i++)
        printf("%d ", a[i]);
    return 0;
}
