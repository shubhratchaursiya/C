#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_KEYWORDS 32

char *keywords[MAX_KEYWORDS] = {
    "auto", "break", "case", "char", "const", "continue", "default", "do",
    "double", "else", "enum", "extern", "float", "for", "goto", "if",
    "int", "long", "register", "return", "short", "signed", "sizeof",
    "static", "struct", "switch", "typedef", "union", "unsigned", "void",
    "volatile", "while"
};
int isKeyword(char *word) {
    for (int i = 0; i < MAX_KEYWORDS; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

int main() {
    FILE *fp;
    char filename[100], word[50];
    int keywordCount = 0;

    printf("Enter filename: ");
    scanf("%s", filename);

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return 1;
    }
    while (fscanf(fp, "%49s", word) != EOF) {
        // Clean punctuation (e.g., "int;" → "int")
        int len = strlen(word);
        while (len > 0 && ispunct(word[len - 1])) {
            word[len - 1] = '\0';
            len--;
        }

        if (isKeyword(word)) {
            keywordCount++;
        }
    }

    fclose(fp);

    printf("Total number of keywords in file: %d\n", keywordCount);

    return 0;
}
