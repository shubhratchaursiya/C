#include <stdio.h>

int sumOfDigits(int n) {
    int sum = 0;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

int main() {
    FILE *fp;
    fp = fopen("C:\Users\\shubh\\Music\\file.txt", "w");

    if (fp == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    for (int i = 5; i <= 100; i += 5) {
        if (sumOfDigits(i) == 3) {
            fprintf(fp, "# ");
        } else {
            fprintf(fp, "%d ", i);
        }
    }

    fclose(fp);
    printf("File written successfully.\n");

    return 0;
}