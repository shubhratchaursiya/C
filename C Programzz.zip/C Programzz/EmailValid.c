#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isValidEmail(const char *email) {
    int len = strlen(email);
    int atCount = 0;
    int atPos = -1;

    for (int i = 0; i < len; i++) {
        char ch = email[i];
        if (!(isalnum(ch) || ch == '@' || ch == '.' || ch == '_' || ch == '-')) {
            return 0; 
        }
        if (ch == '@') {
            atCount++;
            atPos = i;
        }
    }
    if (atCount != 1) return 0;
    if (atPos == 0) return 0;
    if (atPos == len - 1) return 0;
    const char *domain = email + atPos + 1;
    const char *dot = strchr(domain, '.');
    if (dot == NULL) return 0;
    if (dot == domain || dot == domain + strlen(domain) - 1) return 0;
    return 1; 
}

int main() {
    char email[100];

    printf("Enter an email address: ");
    scanf("%s", email);

    if (isValidEmail(email))
        printf("Valid email format.\n");
    else
        printf("Invalid email format.\n");

    return 0;
}
