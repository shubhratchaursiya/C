#include<stdio.h>
#include<string.h>
int main() {}
    char data[100], stuffedData[200];
    int i, j = 0, count = 0;
    printf("Enter the binary data: ");
    scanf("%s", data);
    for(i = 0; i < strlen(data); i++) {
        stuffedData[j] = data[i];
        if(data[i] == '1') {
            count++;
        } else {
            count = 0;
        }
        if(count == 5) {
            j++;
            stuffedData[j] = '0';
            count = 0;
        }
        j++;
    }
    stuffedData[j] = '\0'; 
    printf("Stuffed data: %s\n", stuffedData);
    return 0;
}
