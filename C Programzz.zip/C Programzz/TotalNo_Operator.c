#include <stdio.h>
#include <string.h>

int isOperatorChar(char c) {
    char ops[] = "+-*/%=!<>&|^~";
    for (int i = 0; ops[i] != '\0'; i++) {
        if (c == ops[i])
            return 1;
    }
    return 0;
}

int main() {
    FILE *fp;
    char filename[100];
    char ch, prev = '\0';
    int operatorCount = 0;

    printf("Enter filename: ");
    scanf("%s", filename);

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    while ((ch = fgetc(fp)) != EOF) {
        // check for multi-character operators
        if ((prev == '+' && ch == '+') || (prev == '-' && ch == '-') ||
            (prev == '=' && ch == '=') || (prev == '!' && ch == '=') ||
            (prev == '<' && ch == '=') || (prev == '>' && ch == '=') ||
            (prev == '&' && ch == '&') || (prev == '|' && ch == '|') ||
            (prev == '<' && ch == '<') || (prev == '>' && ch == '>') ||
            (prev == '+' && ch == '=') || (prev == '-' && ch == '=') ||
            (prev == '*' && ch == '=') || (prev == '/' && ch == '=') ||
            (prev == '%' && ch == '=') || (prev == '&' && ch == '=') ||
            (prev == '|' && ch == '=') || (prev == '^' && ch == '=')) {
            operatorCount++;
            prev = '\0';  // reset prev to avoid double counting
            continue;
        }

        // check for single-character operators
        if (isOperatorChar(ch)) {
            operatorCount++;
        }

        prev = ch;
    }

    fclose(fp);

    printf("Total number of operators in file: %d\n", operatorCount);

    return 0;
}
