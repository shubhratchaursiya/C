#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp;
    char filename[100];
    int ch;
    int count[256] = {0}; // ASCII characters count (0-255)

    // Asking user for file name
    printf("Enter the filename: ");
    scanf("%s", filename);

    // Opening file in read mode
    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: Cannot open file %s\n", filename);
        exit(1);
    }

    // Reading each character and counting
    while ((ch = fgetc(fp)) != EOF) {
        count[ch]++;
    }

    fclose(fp);

    // Printing character counts
    printf("\nCharacter Frequency in file:\n");
    for (int i = 0; i < 256; i++) {
        if (count[i] > 0) {
            if (i == '\n')
                printf("'\\n' : %d\n", count[i]);
            else if (i == '\t')
                printf("'\\t' : %d\n", count[i]);
            else if (i == ' ')
                printf("' ' (space) : %d\n", count[i]);
            else
                printf("'%c' : %d\n", i, count[i]);
        }
    }

    return 0;
}