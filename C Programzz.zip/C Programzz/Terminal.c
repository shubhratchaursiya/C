#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_SYMBOLS 100
#define MAX_PRODUCTIONS 100

typedef struct {
    char lhs;
    char rhs[20];
} Production;

Production grammar[MAX_PRODUCTIONS];
int numProductions = 0;
char nonTerminals[MAX_SYMBOLS];
int numNonTerminals = 0;
char terminals[MAX_SYMBOLS];
int numTerminals = 0;
char firstSets[MAX_SYMBOLS][MAX_SYMBOLS];
int firstSetSizes[MAX_SYMBOLS] = {0};

int isTerminal(char symbol) {
    return islower(symbol) || symbol == 'ε';
}

int isNonTerminal(char symbol) {
    return isupper(symbol);
}

int indexOfNonTerminal(char symbol) {
    for (int i = 0; i < numNonTerminals; i++) {
        if (nonTerminals[i] == symbol) return i;
    }
    return -1;
}

void addToFirstSet(char nonTerminal, char symbol) {
    int idx = indexOfNonTerminal(nonTerminal);
    if (idx == -1) return;
    for (int i = 0; i < firstSetSizes[idx]; i++) {
        if (firstSets[idx][i] == symbol) return;
    }
    firstSets[idx][firstSetSizes[idx]++] = symbol;
}

void computeFirstForNonTerminal(char nonTerminal);

void computeFirstForString(char *str, char *resultSet, int *resultSize) {
    *resultSize = 0;
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        char symbol = str[i];
        if (isTerminal(symbol)) {
            resultSet[(*resultSize)++] = symbol;
            return;
        } else if (isNonTerminal(symbol)) {
            int ntIndex = indexOfNonTerminal(symbol);
            if (ntIndex == -1) continue;
            int hasEpsilon = 0;
            for (int j = 0; j < firstSetSizes[ntIndex]; j++) {
                if (firstSets[ntIndex][j] == 'ε') {
                    hasEpsilon = 1;
                } else {
                    int exists = 0;
                    for (int k = 0; k < *resultSize; k++) {
                        if (resultSet[k] == firstSets[ntIndex][j]) {
                            exists = 1;
                            break;
                        }
                    }
                    if (!exists) {
                        resultSet[(*resultSize)++] = firstSets[ntIndex][j];
                    }
                }
            }
            if (!hasEpsilon) return;
        } else {
            continue;
        }
    }
    int exists = 0;
    for (int k = 0; k < *resultSize; k++) {
        if (resultSet[k] == 'ε') {
            exists = 1;
            break;
        }
    }
    if (!exists) {
        resultSet[(*resultSize)++] = 'ε';
    }
}

void computeFirstForNonTerminal(char nonTerminal) {
    int ntIndex = indexOfNonTerminal(nonTerminal);
    if (ntIndex == -1) return;
    for (int i = 0; i < numProductions; i++) {
        if (grammar[i].lhs == nonTerminal) {
            char tempSet[MAX_SYMBOLS];
            int tempSize;
            computeFirstForString(grammar[i].rhs, tempSet, &tempSize);
            for (int j = 0; j < tempSize; j++) {
                addToFirstSet(nonTerminal, tempSet[j]);
            }
        }
    }
}

int main() {
    printf("Enter the number of productions: ");
    scanf("%d", &numProductions);
    getchar(); // Consume newline

    printf("Enter the productions (format: A->XYZ):\n");
    for (int i = 0; i < numProductions; i++) {
        char input[50];
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = 0;
        grammar[i].lhs = input[0];
        strcpy(grammar[i].rhs, &input[3]);
        
        // Collect non-terminals
        int exists = 0;
        for (int j = 0; j < numNonTerminals; j++) {
            if (nonTerminals[j] == grammar[i].lhs) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            nonTerminals[numNonTerminals++] = grammar[i].lhs;
        }
    }

    // Initialize FIRST sets
    for (int i = 0; i < numNonTerminals; i++) {
        computeFirstForNonTerminal(nonTerminals[i]);
    }

    // Compute FIRST sets until no changes
    int changed;
    do {
        changed = 0;
        int oldSizes[MAX_SYMBOLS];
        for (int i = 0; i < numNonTerminals; i++) {
            oldSizes[i] = firstSetSizes[i];
        }
        for (int i = 0; i < numNonTerminals; i++) {
            computeFirstForNonTerminal(nonTerminals[i]);
        }
        for (int i = 0; i < numNonTerminals; i++) {
            if (firstSetSizes[i] != oldSizes[i]) {
                changed = 1;
                break;
            }
        }
    } while (changed);

    // Print FIRST sets
    printf("\nFIRST sets:\n");
    for (int i = 0; i < numNonTerminals; i++) {
        printf("FIRST(%c) = { ", nonTerminals[i]);
        for (int j = 0; j < firstSetSizes[i]; j++) {
            printf("%c ", firstSets[i][j]);
        }
        printf("}\n");
    }

    return 0;
}