#include <stdio.h>
#include <ctype.h>
#include <string.h>
#define MAX 20

char production[MAX][MAX];  
char firstSet[MAX][MAX];   
int n;                       

int isNonTerminal(char c) {
    return (c >= 'A' && c <= 'Z');
}

void findFirst(char *result, char c) {
    int i, j;
    char subResult[MAX];

    if (!isNonTerminal(c)) {
        strncat(result, &c, 1);
        return;
    }
    for (i = 0; i < n; i++) {
        if (production[i][0] == c) {
        
            for (j = 2; production[i][j] != '\0'; j++) {
                char sym = production[i][j];

        
                char temp[MAX] = "";
                findFirst(temp, sym);

                int k;
                int epsilonFound = 0;
                for (k = 0; temp[k] != '\0'; k++) {
                    if (temp[k] != '#') {
                        if (!strchr(result, temp[k])) { 
                            strncat(result, &temp[k], 1);
                        }
                    } else {
                        epsilonFound = 1;
                    }
                }
                  if (!epsilonFound) 
                    break;
                    
                    if (production[i][j + 1] == '\0') {
                    if (!strchr(result, '#'))
                        strcat(result, "#");
                }
            }
        }
    }
}

int main() {
    int i;
    char result[MAX];

    printf("Enter number of productions: ");
    scanf("%d", &n);

    printf("Enter productions (use # for epsilon, e.g., E->TR | E->#):\n");
    for (i = 0; i < n; i++) {
        scanf("%s", production[i]);
    }

    printf("\nFIRST sets:\n");
    for (i = 0; i < n; i++) {
        char nonTerminal = production[i][0];
        if (!firstSet[nonTerminal - 'A'][0]) {
            strcpy(result, "");
            findFirst(result, nonTerminal);
            strcpy(firstSet[nonTerminal - 'A'], result);
        }
    }

    for (i = 0; i < 26; i++) {
        if (firstSet[i][0] != '\0') {
            printf("FIRST(%c) = { ", i + 'A');
            int j;
            for (j = 0; firstSet[i][j] != '\0'; j++) {
                printf("%c ", firstSet[i][j]);
            }
            printf("}\n");
        }
    }

    return 0;
}
