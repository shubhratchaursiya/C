#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to check if a character is an operator
int isOperator(char ch) {
    char operators[] = "+-*/%=<>!&|^~";
    for (int i = 0; i < strlen(operators); i++) {
        if (ch == operators[i])
            return 1;
    }
    return 0;
}

int main() {
    FILE *fp;
    char filename[100];
    char ch;
    int count = 0;

    printf("Enter filename: ");
    scanf("%s", filename);

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error! Cannot open file.\n");
        exit(0);
    }

    while ((ch = fgetc(fp)) != EOF) {
        if (isOperator(ch)) {
            count++;
        }
    }

    fclose(fp);

    printf("Total number of operators in the file: %d\n", count);
    return 0;
}