#include <stdio.h>
int main() {
    char str[] = "Tanisha";
    char *ptr = str;
    int length = 0;
    while (*ptr != '\0') {
        length++;
        ptr++;
    }
    printf("Length = %d", length);
    return 0;
}
