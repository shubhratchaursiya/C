include <stdio.h>

int main() {
    int n, i, sum = 0;

    printf("Enter how many multiples of 5 you want: ");
    scanf("%d", &n);

    int arr[n];
    printf("\nThe numbers are:\n");
    for (i = 0; i < n; i++) {
        arr[i] = 5 * (i + 1);
        printf("%d ", arr[i]);
    }

    printf("\n\nAfter replacing numbers divisible by 3:\n");
    for (i = 0; i < n; i++) {
        if (arr[i] % 3 == 0) {
            sum += arr[i];
            printf("* ");
        } else {
            printf("%d ", arr[i]);
        }
    }
    printf("\n\nSum of numbers divisible by 3 = %d\n", sum);

    return 0;
}