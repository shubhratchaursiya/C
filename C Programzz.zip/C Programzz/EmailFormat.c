#include <stdio.h>
#include <string.h>

 int main() {
    char email[100];
    printf("Enter your email: ");
    scanf("%s", email);

    char *pos = strstr(email, "@gmail.com");

    if (pos != NULL && strcmp(pos, "@gmail.com") == 0) {
        printf("Valid Gmail format\n");
    } else {
        printf("Invalid Gmail format\n");
    }

    return 0;
}
