#include<stdio.h>
#include<conio.h>
int main()
{
    int a,b,c;
    char ch;
    printf("Enter first Character: ");
    scanf("\n 'a' add \n '-' subtract \n 'm' multiply \n 'd' divide \n 'e' exit \n");
    scanf("%c",&ch);
    switch(ch)
    {
        case '+':
            int a,b,sum;
            printf("Enter two numbers: ");
            scanf("%d %d",&a,&b);
            sum=a+b;
            printf("\n sum is %d",sum);
        case '-':
            int a,b,subtract;
            printf("Enter two numbers: ");
            scanf("%d %d",&a,&b);
            subtract=a-b;
            printf("\n subtract is %d",subtract);
        case '*':
            int a,b,multiply;
            printf("Enter two numbers: ");
            scanf("%d %d",&a,&b);
            multiply=a*b;
            printf("\n multiply is %d",multiply);
        case '/':
            int a,b,divide;
            printf("Enter two numbers: ");
            scanf("%d %d",&a,&b);
            divide=a/b;
            printf("\n divide is %d",divide);
            break;
        default:
            printf("Invalid operator");
    }
    getch();
}