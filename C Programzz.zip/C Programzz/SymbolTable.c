#include<stdio.h>
#include<string.h>

#define MAX 5
struct symbol
{
    char symbol[20];
    char type[10];
    char *address;
};
struct symbol table[MAX];
int count=0;

void insert(char name[] char type[] int address){
    if(count< MAX){
        strcpy(table[count].name,name);

    }
}





}
